var app = {
        websocket: null,
        state: {},
        ui: {
            powerBtn: null,
            muteBtn: null,
            mixingBtn: null,
            enhanceBtn: null,
            volumeFR: null,
        },
        onmessage: function (event) {
            var time = 0;
            var json = JSON.parse(event.data);
            if (json) {
                if (json.type == 'state') {
                    app.state = json;
                    app.updateState();
                } else if (json.type == 'user-leave') {
                    writeToScreen('Хтось пішов :( , нас тепер:' + json.count);
                }
            }
            console.log(json);
        },

        sendBoolean: function (name) {
            app.websocket.send(JSON.stringify({'name': name}));
        },

        sendRange: function (name, val) {
            app.websocket.send(JSON.stringify({'name': name, val: val}));
        },

        updateState: function () {
            app.ui.powerBtn.attr('class', app.state.power ? 'btn btn-danger' : 'btn btn-success');
            app.ui.muteBtn.attr('class', app.state.mute ? 'btn btn-danger' : 'btn btn-success');
            app.ui.mixingBtn.attr('class', app.state.mixing ? 'btn btn-danger' : 'btn btn-success');
            app.ui.enhanceBtn.attr('class', app.state.enhance ? 'btn btn-danger' : 'btn btn-success');
            app.ui.volumeFR.val(app.state.volumeFR);
            app.ui.volumeFL.val(app.state.volumeFL);
            app.ui.volumeRR.val(app.state.volumeRR);
            app.ui.volumeRL.val(app.state.volumeRL);
            app.ui.volumeCEN.val(app.state.volumeCEN);
            app.ui.volumeSW.val(app.state.volumeSW);
            app.ui.volumeALLCH.val(app.state.volumeALLCH);
            console.log(app.state.frequency);
            app.ui.frequency.val(app.state.frequency);
            jQuery('#freq').html(app.state.frequency);

        },

        init: function () {

            if (location.host == '') {
                app.websocket = new WebSocket("ws://192.168.1.59/");
            } else {
                app.websocket = new WebSocket("ws://" + location.host + "/");
            }

            app.websocket.onmessage = app.onmessage;

            app.ui.powerBtn = jQuery('#power');
            app.ui.muteBtn = jQuery('#mute');
            app.ui.mixingBtn = jQuery('#mixing');
            app.ui.enhanceBtn = jQuery('#enhance');

            app.ui.volumeFR = jQuery('#volumeFR');
            app.ui.volumeFL = jQuery('#volumeFL');
            app.ui.volumeRR = jQuery('#volumeRR');
            app.ui.volumeRL = jQuery('#volumeRL');
            app.ui.volumeCEN = jQuery('#volumeCEN');
            app.ui.volumeSW = jQuery('#volumeSW');
            app.ui.volumeALLCH = jQuery('#volumeALLCH');
            app.ui.frequency = jQuery('#frequency');

            app.attachButtonHandler(app.ui.powerBtn);
            app.attachButtonHandler(app.ui.mixingBtn);
            app.attachButtonHandler(app.ui.muteBtn);
            app.attachButtonHandler(app.ui.enhanceBtn);
            //
            //app.ui.frequency.change(function () {
            //    app.sendVal('frequency', app.ui.frequency.val());
            //});

            app.attachRangeHandler(app.ui.frequency);

            app.attachRangeHandler(app.ui.volumeFR);
            app.attachRangeHandler(app.ui.volumeFL);
            app.attachRangeHandler(app.ui.volumeRR);
            app.attachRangeHandler(app.ui.volumeRL);
            app.attachRangeHandler(app.ui.volumeCEN);
            app.attachRangeHandler(app.ui.volumeSW);
            app.attachRangeHandler(app.ui.volumeALLCH);




        },

        attachButtonHandler: function (btn) {
            btn.click(function () {
                app.sendBoolean(btn.attr('id'));
            });
        }
        ,
        attachRangeHandler: function (range) {
            range.change(function () {
                console.log(range.attr('id'), range.val());
                app.sendRange(range.attr('id'), range.val());
            });
        }

    }
    ;


console.log('{' + location.host + '}');

window.addEventListener("load", function () {

        app.init();


        var updateState = function (state) {

            console.log(state);
            Object.each(state, function (val, key) {
                var els = document.getElements('.' + key);
                console.log(els);
                if (els.length == 1) {

                    var el = els[0];
                    if (el.hasClass('volume')) {
                        // el.addEvent('change', changeVolume);
                        el.set('value', val);
                    } else if (el.hasClass('mute')) {
                        if (val == 1) {
                            el.addClass('active');
                        }
                        //el.addEvent('click', changeMute);

                    } else if (el.hasClass('backlight')) {

                        if (val == 1) {
                            el.addClass('active');
                        }

                        //el.addEvent('click', changeBacklight);

                    } else if (el.hasClass('mixing')) {

                        if (val == 1) {
                            el.addClass('active');
                        }

                        //el.addEvent('click', changeMixing);
                    } else if (el.hasClass('enhance')) {

                        if (val == 1) {
                            el.addClass('active');
                        }

                        //el.addEvent('click', changeEnhance);

                    } else if (el.hasClass('mute')) {
                        if (val == 1) {
                            el.addClass('active');
                        }
                        //el.addEvent('click', changeMute);

                    } else if (el.hasClass('frequency')) {
                        document.id('freq').set('html', val);
                        el.set('value', val * 10);
                        //el.addEvent('change', changeTuner);
                        el.addEvent('input', function () {
                            document.id('freq').set('html', (this.get('value') / 10).toFixed(1));
                        });
                    }
                } else {
                    if (els.hasClass('source')) {
                        els.each(function (el) {
                            //el.addEvent('click', changeSource);
                            if (el.get('data-source') == val) {
                                el.addClass('active');
                            }
                        })
                    }
                }
                console.log($('.' + key));
            });
            console.log(state);
        };


        var message = document.getElementById("message");
        results = document.getElementById("results");


        // message.onkeyup = function (e) {

        //     if(e.keyCode == 13){
        //         websocket.send(e.target.value);
        //         e.target.value = "";
        //     }
        // };


        return;
        if (location.host == '') {
            websocket = new WebSocket("ws://192.168.1.59/");
        } else {
            websocket = new WebSocket("ws://" + location.host + "/");
        }
        websocket.onopen = function (evt) {
            console.log('connected');
            console.log(evt);
        };
        websocket.onclose = function (evt) {
            console.log(evt);
        };
        websocket.onmessage = function (event) {
            var time = 0;
            var json = JSON.parse(event.data);
            if (json) {
                if (json.type == 'state') {
                    updateState(json);
                } else if (json.type == 'user-leave') {
                    writeToScreen('Хтось пішов :( , нас тепер:' + json.count);
                }
            }
            console.log(json);
        };
        websocket.onerror = function (evt) {
            console.log('onerror');

            console.log(evt);
        };

    },
    false
)
;